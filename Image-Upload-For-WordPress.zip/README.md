## Image-Upload-For-WordPress

作者：TORYS

博客：https://www.rruu.net

WordPress快速上传图片至如优图床

## 说明

* 登录`WordPress`后台
* 安装插件
* 上传插件
* 配置好图床信息

## 演示图

[![https://pic.abcyun.co/image/5ef316692ebf0.jpg](https://pic.abcyun.co/image/5ef316692ebf0.jpg)](https://pic.abcyun.co/image/5ef316692ebf0.jpg)

[![https://pic.abcyun.co/image/5ef316f4a9ad7.jpg](https://pic.abcyun.co/image/5ef316f4a9ad7.jpg)](https://pic.abcyun.co/image/5ef316f4a9ad7.jpg)

[![https://pic.abcyun.co/image/5ef31722a3b19.jpg](https://pic.abcyun.co/image/5ef31722a3b19.jpg)](https://pic.abcyun.co/image/5ef31722a3b19.jpg)